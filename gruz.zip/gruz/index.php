<?php
include 'temp/head.php';
session_start();

if(!empty($_SESSION['id_user'])){
    if($_SESSION['role']=="manager"){
        include "temp/nav1.php";
    }
    elseif($_SESSION['role'] == "accountant"){

        include "temp/accountant.php";
    }
}
else {

    include "temp/nav.php";
    
}

include 'temp/database.php';

?>

<br><br>

<h2>Оставить заявку на грузоперевозку</h2>
        <form action="submit_request.php" method="POST">
            <label for="name">Ваше имя:</label><br>
            <input type="text" id="name" name="name" required><br><br>

            <label for="phone">Телефон:</label><br>
            <input type="tel" id="phone" name="phone" required><br><br>

            <label for="email">Электронная почта:</label><br>
            <input type="email" id="email" name="email" required><br><br>

            <label for="cargo">Тип груза:</label><br>
            <input type="text" id="cargo" name="cargo" required>
            <option value="" disabled  selected>Выберите тип груза</option>
            <option value="general">Общий груз</option>
            <option value="liquid">Жидкости</option>
            <option value="fragile">Хрупкий груз</option>
            <option value="heavy">Тяжелый груз</option>
            <option value="harzardous">Опасный груз</option>
            <option value="refrigerated">Охлажденный груз</option>
</select>

            <br><br>

            <label for="pickup">Место отправления:</label><br>
            <input type="text" id="pickup" name="pickup" required><br><br>

            <label for="destination">Место назначения:</label><br>
            <input type="text" id="destination" name="destination" required><br><br>

            <label for="date">Дата перевозки:</label><br>
            <input type="date" id="date" name="date" required><br><br>

            <button type="submit">Отправить заявку</button>
        </form>
    </main>
<?php
    include 'temp/footer';
    ?>
<?php
$mysqli  = new mysqli ("localhost","root", "", "gruzoperevozki");
$mysqli->set_charset("utf8");


?>

<header>
        <h1>Грузоперевозки по всей стране</h1>
        <nav>
            <ul>
                <li><a href="index.php">Главная</a></li>
                <li><a href="logout.php">Выйти</a></li>
            </ul>
        </nav>
    </header>

    <main>
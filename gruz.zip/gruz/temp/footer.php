<footer style="margin-top:30px;" >
        <div class="container bg-dark text-white">
            <div class="row">
         <div class="row"style="background-color:black;">

         
             <div class="col-4">                    
             
               <!-- <p class = "p1">-->
                Наши Контакты :<br>
                
                <a class="phone" href="#"><i class="fa fa-phone"></i>8(861)212-12-51</a>&nbsp;&nbsp;<br>
                <a class="envelope" href="#"><i class="fa fa-envelope"></i>gruz@mail.ru</a><br>
               
                Юр. адрес: 344047. г.Ростов-на-Дону.<br> ул.Красноармейская, 10
                </div>
                <div class="col-4">   
            <div class="textcopy"style="text-align:center;margin-left:5px; margin-top:30px;">

            <p>Copyright 2024</p>
</div>
</div>
             <div class="col-4">
                <div class="text">
                    <h5>Подписывайтесь на нас в социальных сетях:</h5>
               <img src="img/twitter_icon.png "style="width:55px;">
               <img src="img/eath.png "style="width:55px;">  
                            <img src="img/1(3).png "style="width:80px;">
             </div>
             </div>
           
            


    </footer>
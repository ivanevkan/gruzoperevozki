<?php
include 'temp/head.php';
include 'temp/database.php';
include 'temp/nav.php' 
?>
<div class="container-fluid" style="text-align:center">
<h1 style="color:black">НАШИ КОНТАКТЫ </h1>
<p style="font-size:medium">город Ростов-на-Дону<br>
 Наш адрес: проспект Красноамейский 10<br>
Телефоны: 2236752<br>
       +79985365211
</p>
<img src="img/card.jpg" class="img-fluid"style="width: 600px;height: 500px;padding-top: 15px; padding-right: 7px; padding-bottom:9px;">
<?php
  
include 'temp/footer.php';
?>